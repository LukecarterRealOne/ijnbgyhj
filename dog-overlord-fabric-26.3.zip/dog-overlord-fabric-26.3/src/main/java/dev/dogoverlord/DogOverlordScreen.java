package dev.dogoverlord;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Animated neon control panel for the DOG OVERLORD client. */
public final class DogOverlordScreen extends Screen {
    private static final int BUTTON_WIDTH = 150;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 10;

    private Button autoTameButton;
    private Button packMinusButton;
    private Button packPlusButton;

    public DogOverlordScreen() {
        super(Component.literal("DOG OVERLORD"));
    }

    /** Keep the single-player world ticking while the live control panel is open. */
    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;
        int left = centerX - BUTTON_WIDTH - BUTTON_GAP / 2;
        int right = centerX + BUTTON_GAP / 2;
        int row1 = centerY - 82;
        int row2 = centerY - 54;
        int row3 = centerY - 26;
        int row4 = centerY + 2;
        int closeY = centerY + 30;

        autoTameButton = this.addRenderableWidget(Button.builder(autoTameLabel(), button -> {
            DogOverlordClient.toggleAutoTame();
            button.setMessage(autoTameLabel());
        }).bounds(left, row1, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addRenderableWidget(Button.builder(Component.literal("TAME ALL  »"), button -> {
            DogOverlordClient.startTameAll(Minecraft.getInstance());
            refreshLabels();
        }).bounds(right, row1, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        packMinusButton = this.addRenderableWidget(Button.builder(packMinusLabel(), button -> {
            DogOverlordClient.adjustMaxPackSize(-5);
            refreshLabels();
        }).bounds(left, row2, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        packPlusButton = this.addRenderableWidget(Button.builder(packPlusLabel(), button -> {
            DogOverlordClient.adjustMaxPackSize(5);
            refreshLabels();
        }).bounds(right, row2, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addRenderableWidget(Button.builder(Component.literal("PACK: ALL SIT"), button -> {
            DogOverlordClient.commandPackFromMenu(true);
        }).bounds(left, row3, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addRenderableWidget(Button.builder(Component.literal("PACK: ALL FOLLOW"), button -> {
            DogOverlordClient.commandPackFromMenu(false);
        }).bounds(right, row3, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addRenderableWidget(Button.builder(Component.literal("RECALL MY WOLVES"), button -> {
            DogOverlordClient.recallPack(Minecraft.getInstance());
        }).bounds(left, row4, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addRenderableWidget(Button.builder(Component.literal("NAME NEAREST"), button -> {
            DogOverlordClient.nameNearestOwnedWolf(Minecraft.getInstance());
        }).bounds(right, row4, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addRenderableWidget(Button.builder(Component.literal("CLOSE MENU"), button -> {
            Minecraft.getInstance().setScreen(null);
        }).bounds(centerX - BUTTON_WIDTH, closeY, BUTTON_WIDTH * 2 + BUTTON_GAP, BUTTON_HEIGHT).build());
    }

    private void refreshLabels() {
        if (autoTameButton != null) autoTameButton.setMessage(autoTameLabel());
        if (packMinusButton != null) packMinusButton.setMessage(packMinusLabel());
        if (packPlusButton != null) packPlusButton.setMessage(packPlusLabel());
    }

    private static Component autoTameLabel() {
        return Component.literal("AUTO-TAME: " + (DogOverlordClient.isAutoTameEnabled() ? "ON" : "OFF"));
    }

    private static Component packMinusLabel() {
        return Component.literal("PACK LIMIT: -5  (" + DogOverlordClient.getMaxPackSize() + ")");
    }

    private static Component packPlusLabel() {
        return Component.literal("PACK LIMIT: +5  (" + DogOverlordClient.getMaxPackSize() + ")");
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        long time = System.currentTimeMillis();
        double wave = (Math.sin(time / 280.0) + 1.0) / 2.0;
        int pulse = (int) (150 + 105 * wave);
        int neonPink = (pulse << 24) | (255 << 16) | (70 << 8) | 220;
        int neonCyan = (0xFF << 24) | (70 << 16) | (225 << 8) | pulse;

        int cx = this.width / 2;
        int cy = this.height / 2;
        int panelLeft = cx - 176;
        int panelRight = cx + 176;
        int panelTop = cy - 132;
        int panelBottom = cy + 112;

        // Draw behind the widgets; subtly animated scan line and pulsing neon edges.
        graphics.fill(0, 0, this.width, this.height, 0xA8040616);
        graphics.fill(panelLeft, panelTop, panelRight, panelBottom, 0xEA0B0D22);
        graphics.fill(panelLeft, panelTop, panelRight, panelTop + 2, neonPink);
        graphics.fill(panelLeft, panelBottom - 2, panelRight, panelBottom, neonCyan);
        graphics.fill(panelLeft, panelTop, panelLeft + 2, panelBottom, neonCyan);
        graphics.fill(panelRight - 2, panelTop, panelRight, panelBottom, neonPink);
        int scanY = panelTop + 4 + (int) ((time / 15L) % Math.max(1, panelBottom - panelTop - 8));
        graphics.fill(panelLeft + 3, scanY, panelRight - 3, scanY + 1, 0x36FF55E8);

        super.extractRenderState(graphics, mouseX, mouseY, delta);

        String title = "DOG OVERLORD";
        graphics.text(this.font, title, cx - this.font.width(title) / 2, cy - 119, neonPink, true);

        String subtitle = "W O L F   C O N T R O L   S Y S T E M  //  v2.0";
        graphics.text(this.font, subtitle, cx - this.font.width(subtitle) / 2, cy - 101, neonCyan, true);

        String count = "OWNED WOLVES LOADED NEARBY: "
                + DogOverlordClient.getOwnedWolfCount(Minecraft.getInstance())
                + "   |   LIMIT: " + DogOverlordClient.getMaxPackSize();
        graphics.text(this.font, count, cx - this.font.width(count) / 2, cy + 61, 0xFFFFFFFF, true);

        String namingHint = "NAMING: rename a Name Tag in an anvil, hold it, then NAME NEAREST / N";
        graphics.text(this.font, namingHint, cx - this.font.width(namingHint) / 2, cy + 77, 0xFFD7CFFF, false);

        String recallHint = "RECALL needs cheats/operator permission; server rules still apply.";
        graphics.text(this.font, recallHint, cx - this.font.width(recallHint) / 2, cy + 91, 0xFF9CA8CF, false);
    }
}
