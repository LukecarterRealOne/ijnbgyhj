# DOG OVERLORD — Fabric Wolf Companion Mod

**Target:** Minecraft Java Edition 26.3 · Fabric Loader 0.19.5+ · Fabric API 0.165.0+26.3 · Java 25  
**Project version:** 2.0.0  
**Side:** Client-only Fabric mod

DOG OVERLORD is a client-side companion toolkit for single-player worlds and servers where you have permission to use its features. Normal tame, owner-interaction, and name-tag use is sent to the game/server. The recall button sends a vanilla `/tp` command which remains subject to server command permissions; it does not bypass anti-cheat or server authority.

## Features

- **Animated neon GUI:** open the custom dark neon panel with `G`.
- **Auto-Tame:** holds a bone in either hand and automatically interacts with the nearest wild wolf within 6 blocks every 12 ticks. Vanilla taming chance, bone consumption and server checks still apply.
- **Tame All:** starts Auto-Tame and continues through nearby wild wolves until the configured pack limit is reached. Stay near the wolves and carry enough bones; it does not spawn wolves.
- **Pack limit:** use `PACK LIMIT -5` / `PACK LIMIT +5` in the GUI to set a maximum between 1 and 100. The setting persists in `.minecraft/config/dog-overlord.properties`. The limit counts owned wolves currently visible to the client within 96 blocks, so wolves in unloaded chunks or beyond that radius cannot be counted by a client-only mod.
- **Pack: All Sit / All Follow:** uses ordinary owner interactions for owned wolves within 6 blocks. Keep your main hand empty to avoid accidentally using an item.
- **Recall My Wolves:** issues a vanilla `/tp` command matching wolves' `Owner` UUID against your player UUID. This requires cheats enabled in single-player or operator/command permission on a server. The game/server may reject it, and its chat response is the definitive result. It only affects loaded entities and cannot force chunks to load.
- **Name Nearest:** use a Name Tag renamed in an anvil, hold it in either hand, then press `N` or click the GUI button. The mod sends a normal interaction to the nearest owned wolf; the server decides whether it applies.

## Keybinds

Open **Options → Controls → Key Binds → DOG OVERLORD** to change these bindings.

| Key | Action |
|---|---|
| `G` | Open the DOG OVERLORD menu |
| `R` | Toggle Auto-Tame |
| `H` | Ask nearby owned wolves to sit |
| `J` | Ask nearby owned wolves to follow |
| `P` | Recall owned wolves with a vanilla command (permission required) |
| `N` | Apply a held, renamed Name Tag to the nearest owned wolf |

## Build on Windows

1. Install a **JDK 25** and make sure `java -version` reports Java 25.
2. Extract this project to a normal folder.
3. Run `build.bat` from the extracted project folder.
4. After a successful build, the mod JAR will be in `build/libs/`.
5. Install Fabric Loader for Minecraft 26.3 and Fabric API for 26.3, then place `dog-overlord-mc26.3-2.0.0.jar` in `%appdata%\.minecraft\mods`.

## Build on macOS/Linux

1. Install a JDK 25.
2. Run `chmod +x build.sh && ./build.sh` from the project folder.
3. After a successful build, the JAR will be in `build/libs/`.

The build scripts use Gradle 9.7.0 if system Gradle is not installed and download it from Gradle's official distribution host. Minecraft/Fabric dependencies are fetched by Gradle on the first build.

## Important limitations

- This archive is source code and build scripts; it is **not a compiled or tested JAR**.
- The mod is installed on the client only. On multiplayer servers, the server remains authoritative and may disallow automation or commands.
- The client can only count wolves it currently knows about, and the pack-limit count is bounded to a 96-block radius.
- Naming requires a Name Tag already renamed in an anvil. The mod does not forge item data or change the wolf's name locally.
- Recall requires command permission; vanilla wolves also have their usual follow/teleport behavior when conditions allow.

## Version notes

The source targets Minecraft Java 26.3. API compatibility must be confirmed by a successful build and in-game test on your exact Fabric installation. If Gradle reports errors, share the full error output and the failing file/line so the source can be adjusted.
